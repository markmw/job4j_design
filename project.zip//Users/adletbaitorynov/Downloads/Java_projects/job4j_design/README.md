# job4j_design

Design - проект, в котором подробно рассматривается работа с:
1. Maven. 
2. Iterator. 
3. Generic. 
4. List. 
5. Set. 
6. Map. 
7. Tree.